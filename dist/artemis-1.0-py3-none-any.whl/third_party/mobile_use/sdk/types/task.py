# Copyright 2025-2026 Minitap, Inc.
# Modifications Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Originally from mobile-use (https://github.com/minitap-ai/mobile-use).
# See third_party/mobile_use/METADATA for the upstream source and local modifications.

"""Task-related type definitions for the ARTEMIS SDK."""

from collections.abc import Callable, Coroutine
from datetime import datetime
from pathlib import Path
from typing import Any, Generic, Literal, TypeVar, overload

from artemis.config import LLMConfig, get_default_llm_config
from artemis.constants import RECURSION_LIMIT
from artemis.context import DeviceContext
from artemis.sdk.utils import load_llm_config_override
from pydantic import BaseModel, Field
from artemis.utils.cython_compat import CyFunctionDetector

TaskRunStatus = Literal["pending", "running", "completed", "failed", "cancelled"]


class AgentProfile(BaseModel):
    """Represents a ARTEMIS agent profile.

    Attributes:
        name: Name of the agent - used to reference the agent when running
          tasks.
        llm_config: LLM configuration for the agent.
    """

    model_config = {"ignored_types": (CyFunctionDetector,)}

    name: str
    llm_config: LLMConfig = Field(default_factory=get_default_llm_config)

    @overload
    def __init__(self, *, name: str, llm_config: LLMConfig): ...

    @overload
    def __init__(self, *, name: str, from_file: str): ...

    def __init__(
        self,
        *,
        name: str,
        llm_config: LLMConfig | None = None,
        from_file: str | None = None,
        **kwargs,
    ):
        kwargs["name"] = name
        if from_file:
            kwargs["llm_config"] = load_llm_config_override(Path(from_file))
        elif llm_config:
            kwargs["llm_config"] = llm_config
        else:
            raise ValueError("Either llm_config or from_file must be provided")
        super().__init__(**kwargs)

    def __str__(self):
        return f"Profile {self.name}:\n{self.llm_config}"


T = TypeVar("T", bound=BaseModel)
TOutput = TypeVar("TOutput", bound=BaseModel | None)


class TaskRequestBase(BaseModel):
    """Defines common parameters of a mobile automation task request."""

    model_config = {"ignored_types": (CyFunctionDetector,)}
    max_steps: int = RECURSION_LIMIT
    record_trace: bool = True
    trace_path: Path = Path("traces")
    llm_output_path: Path | None = None


class TaskRequestCommon(TaskRequestBase):
    """Defines common parameters for any task request."""

    model_config = {"ignored_types": (CyFunctionDetector,)}
    max_steps: int = RECURSION_LIMIT
    locked_app_package: str | None = None
    app_path: Path | None = None
    """Path to an app to install before running the task.
    
    For Android: Path to an APK file.
    
    The app will be installed automatically before the task starts.
    """


class TaskRequest(TaskRequestCommon, Generic[TOutput]):
    """Defines the format of a mobile automation task request.

    Attributes:
        goal: Natural language description of the goal to achieve
        profile: Optional agent profile to use for executing the task
        task_name: Optional name for the task
        output_description: Optional natural language description of expected
          output format
        output_format: Optional pydantic model for the output format of the task
        max_steps: Maximum number of steps the agent can take (default: 20)
        record_trace: Whether to record a trace (screenshots, actions) of the
          execution (default: False)
        trace_path: Directory path to save trace data if recording is enabled
        llm_output_path: Path to save LLM output data
    """

    model_config = {"ignored_types": (CyFunctionDetector,)}
    goal: str
    profile: str | None = None
    task_name: str | None = None
    output_description: str | None = None
    output_format: type[TOutput] | None = None
    enable_remote_tracing: bool = False


class TaskResult(BaseModel):
    """Result of a mobile automation task.

    Attributes:
        content: Raw result content (could be text or structured data)
        error: Error message if the task failed
        execution_time_seconds: How long the task took to execute
        steps_taken: Number of steps the agent took to complete the task
    """

    model_config = {"ignored_types": (CyFunctionDetector,)}
    content: Any = None
    error: str | None = None
    execution_time_seconds: float
    steps_taken: int

    def get_as_model(self, model_class: type[T]) -> T:
        """Parse the content into a Pydantic model instance.

        Args:
            model_class: The Pydantic model class to parse the data into

        Returns:
            An instance of the specified model class

        Raises:
            ValueError: If content is None or not compatible with the model
        """
        if self.content is None:
            raise ValueError("No content available to parse into a model")
        if isinstance(self.content, model_class):
            return self.content
        return model_class.model_validate(self.content)


class Task(BaseModel):
    """A mobile automation task to be executed.

    Attributes:
        id: Unique identifier for the task
        device: Information about the target device
        status: Current status of the task execution
        request: User task request
        created_at: ISO timestamp when the task was created
        ended_at: ISO timestamp when the task ended
    """

    model_config = {"ignored_types": (CyFunctionDetector,)}
    id: str
    device: DeviceContext
    status: TaskRunStatus
    status_message: str | None = None
    on_status_changed: Callable[[TaskRunStatus, str | None, Any | None], Coroutine] | None = None
    request: TaskRequest
    created_at: datetime
    ended_at: datetime | None = None
    result: TaskResult | None = None

    async def finalize(
        self,
        content: Any | None = None,
        state: dict | None = None,
        error: str | None = None,
        cancelled: bool = False,
    ):
        new_status: TaskRunStatus = "completed" if error is None else "failed"
        if new_status == "failed" and cancelled:
            new_status = "cancelled"
        message = "Task completed successfully"
        if new_status == "failed":
            message = "Task failed" + (f": {error}" if error else "")
        elif new_status == "cancelled":
            message = "Task cancelled" + (f": {error}" if error else "")
        await self.set_status(status=new_status, message=message, output=content or error)
        self.ended_at = datetime.now()

        duration = self.ended_at - self.created_at
        steps_taken = -1
        if state is not None:
            metadata = state.get("metadata", None)
            if metadata:
                steps_taken = metadata.get("step_count", -1)

        self.result = TaskResult(
            content=content,
            error=error,
            execution_time_seconds=duration.total_seconds(),
            steps_taken=steps_taken,
        )

    def get_name(self) -> str:
        return self.request.task_name or self.id

    async def set_status(
        self,
        status: TaskRunStatus,
        message: str | None = None,
        output: Any | None = None,
    ):
        self.status = status
        self.status_message = message
        if self.on_status_changed:
            await self.on_status_changed(status, message, output)
